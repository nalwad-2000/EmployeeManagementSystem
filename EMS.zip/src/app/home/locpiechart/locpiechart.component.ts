import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-locpiechart',
  templateUrl: './locpiechart.component.html',
  styleUrls: ['./locpiechart.component.css']
})
export class LocpiechartComponent  {

  // Pie
  public pieChartLabels:string[] = ['Bangalore', 'Koppal', 'Hubli'];
  public pieChartData:number[] = [50, 40, 20];
  public pieChartType:string = 'pie';
 
  // events
  public chartClicked(e:any):void {
    console.log(e);
  }
 
  public chartHovered(e:any):void {
    console.log(e);
  }

}

