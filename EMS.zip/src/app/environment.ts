export const environment = {
    firebase: {
      apiKey: "AIzaSyDCenvoC16U0u2JOp3HD1npmDIq9ZAjPTM",
      authDomain: "dhiru-employee.firebaseapp.com",
      databaseURL: "https://dhiru-employee.firebaseio.com",
      projectId: "dhiru-employee",
      storageBucket: "dhiru-employee.appspot.com",
      messagingSenderId: "748014364221"
    }
  }