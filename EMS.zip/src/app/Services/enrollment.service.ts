import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs'; 

@Injectable({
  providedIn: 'root'
})
export class EnrollmentService {

  url = 'http://localhost:3000/jobs';
  _url = 'http://localhost:3000/employees';
  parsedstatus: any;
  parsedcurrenstatus:any;
  parsedscheduleinterview: any;
  parsedinterviewername: any;
  parsedinterviewdate: any;
  parsedinterviewtime: any;
  parsednotes: any;
  constructor(private _http:HttpClient) { }

  enroll(value: any){
    return this._http.post<any>(this._url, value); 
  }

  enrolljob(value:any){
    return this._http.post<any>(this.url,value);
  }

  explore() : Observable<any[]>{
    return this._http.get<any[]>(this._url);
  }

  explorejob(): Observable<any[]>{
    return this._http.get<any[]>(this.url);
  }

  exploredetail(_id:number) {
      return this._http.get("http://localhost:3000/employees/"+_id);
  }

  explorejobdetail(_id:number) {
     return this._http.get("http://localhost:3000/jobs/"+_id);
  }

  updatestatus(_id:number,data) {
    return this._http.patch("http://localhost:3000/employees/"+_id,data);
  }

  updatecurrentstatus(_id:number,data) {
    return this._http.patch("http://localhost:3000/employees/"+_id,data);
  }

  updatescheduleinterview(_id:number,data) {
    return this._http.patch("http://localhost:3000/employees/"+_id,data);
  }

  updateinterviewername(_id:number,data) {
    return this._http.patch("http://localhost:3000/employees/"+_id,data);
  }

  updateinterviewdate(_id:number,data){
    return this._http.patch("http://localhost:3000/employees/"+_id,data);
  }

  updateinterviewtime(_id:number,data){
    return this._http.patch("http://localhost:3000/employees/"+_id,data);
  }

  updatenotes(_id:number,data){
    return this._http.patch("http://localhost:3000/employees/"+_id,data);
  }
}
